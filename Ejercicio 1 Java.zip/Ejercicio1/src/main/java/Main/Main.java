/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
import Main.Utilidades;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author gussr
 */
public class Main extends JFrame{

public static void main(String args[]){
Utilidades prueba = new Utilidades();
Scanner leer = new Scanner(System.in);
int rep = 1;
do{
System.out.println("¿Cuantas frases vas a procesar? :)");
int casos = leer.nextInt();
for(int i=0; i<casos; i++){
prueba.leeroriginal(i+1);

}

System.out.println("¿Quieres repetir el proceso?");
System.out.println("1. Si");
System.out.println("2. No");
rep = leer.nextInt();
}while(rep == 1);
}
}
